from keras.layers import Dense, Dropout 
#from keras.layers.recurrent import LSTM, GRU 
from keras.layers import LSTM, GRU 
from keras.models import Sequential 
import pandas as pd 
import numpy as np 
import scipy.io as sio
from keras.layers import Flatten 
from keras.layers import GRU,Bidirectional
from keras.layers import Conv1D, MaxPooling1D
import matplotlib.pyplot as plt 
from sklearn.preprocessing import scale 
from sklearn.metrics import roc_curve, auc 
from sklearn.model_selection import StratifiedKFold 
import utils.tools as utils 
from keras.models import load_model
from tensorflow.keras.utils import plot_model
np.random.seed(42) # To reproduce same results


from imblearn.under_sampling import RandomUnderSampler


# In[3]:


model = Sequential() 
model.add(Bidirectional(GRU(8,return_sequences=True))) 
model.add(Dropout(0.5)) 
model.add(Bidirectional(GRU(4,return_sequences=True)))
model.add(Dropout(0.5)) 
model.add(Flatten())
model.add(Dense(128, activation = 'relu',name="Dense_128"))
model.add(Dense(64, activation = 'relu',name="Dense_64"))
model.add(Dense(32, activation = 'relu',name="Dense_32"))
model.add(Dropout(0.5))
model.add(Dense(2, activation = 'softmax',name="Dense_2"))
model.compile(loss = 'binary_crossentropy', optimizer = 'Adam', metrics =['accuracy'])#rmsprop 


# In[4]:


data_train = sio.loadmat('BBB_RECM_comp_TR.mat')
data = data_train.get('BBB_RECM_comp_TR')  # Remove the data in the dictionary
[m1,n1]=np.shape(data)
label1 = np.ones((215 , 1))  # Value can be changed
label2 = np.zeros((2152, 1))
label = np.append(label1, label2)

shu=scale(data)
X1=shu 
y=label 


#######

ru = RandomUnderSampler(sampling_strategy=215/430, random_state=42)




X_res, y_res = ru.fit_resample(X1,y)


X1 = X_res
y = y_res

#######

X=np.reshape(X1,(-1,1,n1))  
sepscores = []  
ytest=np.ones((1,2))*0.5 
yscore=np.ones((1,2))*0.5 

skf= StratifiedKFold(n_splits=5) 

np.random.seed(42)
for train, test in skf.split(X,y):
    y_train=utils.to_categorical(y[train])
    cv_clf = model 
    history=cv_clf.fit(X[train],  
                    y_train, 
                    epochs=100,
                    verbose=0)  # Versbose = 0 No Epoch profress or verbose = 1 to show Epoch progress 
    y_score=cv_clf.predict(X[test])
    y_class= utils.categorical_probas_to_classes(y_score) 
    
    
    y_test=utils.to_categorical(y[test]) 
    ytest=np.vstack((ytest,y_test)) 
    y_test_tmp=y[test]        
    yscore=np.vstack((yscore,y_score)) 
     
    acc, precision,npv, sensitivity, specificity, mcc,f1 = utils.calculate_performace(len(y_class), y_class, y_test_tmp) 
    fpr, tpr, _ = roc_curve(y_test[:,1], y_score[:,1]) 
    roc_auc = auc(fpr, tpr) 
    sepscores.append([acc, precision,npv, sensitivity, specificity, mcc,f1,roc_auc]) 
     
scores=np.array(sepscores) 
result1=np.mean(scores,axis=0) 
H1=result1.tolist() 
sepscores.append(H1) 
result=sepscores 


# In[5]:


print(model.summary())


# In[6]:


#!pip install pydot

#!sudo apt install graphviz # Need to install from outside


# In[7]:


#plot_model(model, to_file='model_plot.png', show_shapes=True, show_layer_names=True)


# In[8]:


model_save_path = r"DeepBiGRU.h5"   # Saving model to local directory
cv_clf.save(model_save_path)

print("Model saved to disk at:", model_save_path)
 
row=yscore.shape[0] 
yscore=yscore[np.array(range(1,row)),:] 
yscore_sum = pd.DataFrame(data=yscore) 
yscore_sum.to_csv('DeepBiGRUyscore.csv') 

ytest=ytest[np.array(range(1,row)),:] 
ytest_sum = pd.DataFrame(data=ytest) 
ytest_sum.to_csv('DeepBiGRUytest.csv') 

fpr, tpr, _ = roc_curve(ytest[:,0], yscore[:,0])
auc_score=np.mean(scores, axis=0)[7]
colum = ['ACC', 'precision', 'npv', 'Sn', 'Sp', 'MCC', 'F1', 'AUC']
ro = ['1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11']
#ro = ['1', '2', '3']
#data_csv = pd.DataFrame(columns=colum, data=result, index=ro)
data_csv = pd.DataFrame(columns=colum, data=result)  # , index=ro)
data_csv.to_csv(r'DeepBiGRUtrain_results.csv')

#data_csv = pd.DataFrame(columns=colum, data=result, index=ro) 
#data_csv.to_csv('DeepBiGRUtrain.csv') 

lw=2
plt.plot(fpr, tpr, color='darkorange',
lw=lw, label='DeepBiGRU_TR (AUC = %0.3f%%)' % auc_score)
plt.plot([0, 1], [0, 1], color='navy', lw=lw, linestyle='--')
plt.xlim([-0.03, 1.03])
plt.ylim([0.0, 1.05])
plt.xlabel('False Positive Rate')
plt.ylabel('True Positive Rate')
plt.title('Receiver Operating Characteristic')
plt.legend(loc="lower right")
plt.savefig("DeepBiGRU_DCGR_ROC.jpg")
plt.show()


# In[9]:


def indepTesting(Xtest, Ytest):
     Sepscores = []
     ytest = np.ones((1, 2)) * 0.5
     yscore = np.ones((1, 2)) * 0.5
     print("this is the shape of Xtest", Xtest.shape)
     print("this is the shape of Ytest", Ytest.shape)
     xtest = np.vstack(Xtest)
     print("this is the shape of xtest", xtest.shape)
     y_test = np.vstack(Ytest)
     #print("this is the shape of y_test", y_test.shape)
     #saved_model_path = 'C:/Users/Ali/Downloads/ACP-CapsuleGAN_model/ACP-CapsuleGAN_model/model/ali.h5'  # Replace with your model's file path
     #saved_model_path = 'E:/POSTDOC_HBKU/Task7/Papers/ACP/Datasets/ACP_Main/DCGR/Ali_Zakir_CapsuleGAN/model/dcgr.h5'# Replace with your model's file path
     saved_model_path = r"DeepBiGRU.h5"  # local folder
     ldmodel = load_model(saved_model_path)
     print("Loaded model from disk")
     y_score = ldmodel.predict(Xtest)
     yscore = np.vstack((yscore, y_score))
     y_class = utils.categorical_probas_to_classes(y_score)

     fpr, tpr, _ = roc_curve(y_test, y_score[:, 1])
     roc_auc = auc(fpr, tpr)
     acc, precision, npv, sensitivity, specificity, mcc, f1 = utils.calculate_performace(len(y_class), y_class,
                                                                                         y_test)
     Sepscores.append([acc, precision,npv,sensitivity, specificity, mcc,f1,roc_auc])
     print('acc=%f,precision=%f,npv=%f,sensitivity=%f,specificity=%f,mcc=%f,f1=%f,roc_auc=%f'
           % (acc, precision, npv, sensitivity, specificity, mcc, f1, roc_auc))
     fpr, tpr, _ = roc_curve(y_test[:, 0], y_score[:, 1])
     auc_score = auc(fpr, tpr)
     scores = np.array(Sepscores)
     result1 = np.mean(scores, axis=0)
     H1 = result1.tolist()
     Sepscores.append(H1)
     result = Sepscores
     row = y_score.shape[0]
     yscore = y_score[np.array(range(1, row)), :]
     yscore_sum = pd.DataFrame(data=yscore)
     yscore_sum.to_csv('yscore_sum_DCGR_ind.csv')
     y_test = y_test[np.array(range(1, row)), :]
     ytest_sum = pd.DataFrame(data=y_test)
     ytest_sum.to_csv('ytest_sum_DeepBiGRU_ind.csv')
     colum = ['ACC', 'precision', 'npv', 'Sn', 'Sp', 'MCC', 'F1', 'AUC']
     data_csv = pd.DataFrame(columns=colum, data=result)  # , index=ro)
     data_csv.to_csv('Result_DeepBiGRU_ind.csv')
     lw = 2
     plt.plot(fpr, tpr, color='darkorange',
              #lw=lw, label='SVC ROC (area = %0.2f%%)' % auc_score)
              lw=lw, label='DeepBiGRU_DCGR_TS (AUC = %0.3f%%)' % auc_score)
     plt.plot([0, 1], [0, 1], color='navy', lw=lw, linestyle='--')
     plt.xlim([0.0, 1.05])
     plt.ylim([0.0, 1.05])
     plt.xlabel('False Positive Rate')
     plt.ylabel('True Positive Rate')
     plt.title('Receiver Operating Characteristic')
     plt.legend(loc="lower right")
     plt.grid()
     plt.show()
     


# ## Test on indepenedent dataset

# In[11]:


data_test = sio.loadmat('BBB_RECM_comp_TS.mat')
data_test = data_test.get('BBB_RECM_comp_TS')  # Remove the data in the dictionary
print("this is test shape ", data_test.shape)
label1_test = np.ones((54, 1))  # Value can be changed
label2_test = np.zeros((538, 1))
label_test = np.append(label1_test, label2_test)
scale_data = scale(data_test)
label_test = np.array(label_test)
indepxtest = scale_data
indepXtest = np.reshape(indepxtest,(-1,1,n1))
print("indepXtest after reshape ===============>",indepXtest.shape)

indepYtest = label_test
indepTesting(indepXtest, indepYtest)







