def name2path(name):
    """
    Replace '/' in name by '_'
    """
    return name.replace("/", "-")
